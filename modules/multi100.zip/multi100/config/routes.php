<?php

defined('BASEPATH') or exit('No direct script access allowed');

$route['multi100/update'] = 'multi100/gateways/update/index';
